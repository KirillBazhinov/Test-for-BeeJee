<a href="/"><h2>На главную</h2></a>
<p>
<img src="/images/404.jpg" alt="404">
</p>
